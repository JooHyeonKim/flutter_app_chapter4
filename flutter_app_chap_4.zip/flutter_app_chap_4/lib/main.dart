import 'package:flutter/material.dart';
import 'package:flutter_app_chap_4/styles.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  MyApp({Key? key}) : super(key: key);


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primaryColor: AppColor.forestGreen,
        primarySwatch: Colors.indigo,
        fontFamily: 'Cabin',
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  MyHomePage({Key? key}) : super(key: key);
  final students = List.generate(100, (i)=> i+1).toList();
  final dogs = List.generate(16,(i)=>i+1).toList();

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length:3,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: AppColor.forestGreen,
          title: const Text('My Flutter App'),
          actions: [
            IconButton(
              icon: const Icon(
                Icons.add,
              ),
              onPressed: (){},
            ),
          ],
          bottom: const TabBar(
            labelColor: Colors.white,
            tabs: [
              Tab(icon: Icon(Icons.tag_faces), text: 'Students'),
              Tab(icon: Icon(Icons.photo), text: 'Album'),
              Tab(icon: Icon(Icons.info),text: 'Info'),
            ]
          )
          //leading: const Icon(Icons.add),
        ),
        body: TabBarView(
          children: [
            Tab(
              child: SingleChildScrollView(
                child: Column(
                  children : students.map((i)=> ListTile(leading: const Icon(Icons.home), title: Text('student$i'),
                  trailing: const Icon(Icons.navigate_next),)).toList(),
                ),
              ),
            ),
            Tab(
              child: GridView.count(
                crossAxisCount: 3,
                children:
                  dogs.map((i) => Image.asset('assets/images/dog_$i.jpeg'),).toList(),

              ),
            ),
            Tab(
              child: Stack(
                children:[
                  Align(
                    alignment: Alignment.bottomRight,
                    child: Opacity(
                      opacity:0.25,
                      child:Image.asset('assets/images/warning.jpeg',width:300,height:300),
                    ),
                  ),



                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children:[
                      Text('This page does not include contents.',style: TextStyle(fontSize:15),textAlign: TextAlign.center),
                      Text('Please insert contents by pressing this button.\n',style: TextStyle(fontSize:15),textAlign: TextAlign.center),

                      Align(
                        alignment: Alignment.center,
                        child: FloatingActionButton(
                          child: Icon(Icons.add),
                          onPressed: (){},
                        ),
                      ),

                    ],
                  ),


                ],
              )),
          ],
        ),

        drawer: const Drawer(),
        bottomNavigationBar: BottomNavigationBar(
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
            BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
            BottomNavigationBarItem(icon: Icon(Icons.notifications), label: 'Notification'),
          ],
        ),
      ),
    );
  }
}


